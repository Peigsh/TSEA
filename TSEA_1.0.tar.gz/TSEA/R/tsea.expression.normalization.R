tsea.expression.normalization <-
function (query_mat, correction_factor = GTEx_ave_sd, normalization = "abundance") {
query_mat_matched = query_mat[which(rownames(query_mat) %in% correction_factor[,2]),]
query_mat_matched_sd = correction_factor[which(correction_factor[,2] %in% rownames(query_mat_matched)),]
query_mat_matched_sd = query_mat_matched_sd[match(rownames(query_mat_matched), query_mat_matched_sd[,2]),]
query_mat_matched_filter = query_mat_matched[which(query_mat_matched_sd[,4] > 0),]
query_mat_matched_sd_filter = query_mat_matched_sd[which(query_mat_matched_sd[,4] > 0),]
if (normalization == "abundance"){
query_mat_normalized = log2((query_mat_matched_filter)+1)/(log2(as.numeric(as.vector(query_mat_matched_sd_filter[,3]))+1)+1)
}
if (normalization == "zscore"){
query_mat_normalized = (query_mat_matched_filter - as.numeric(as.vector(query_mat_matched_sd_filter[,3])))/as.numeric(as.vector(query_mat_matched_sd_filter[,4]))
}
return(query_mat_normalized)
}
